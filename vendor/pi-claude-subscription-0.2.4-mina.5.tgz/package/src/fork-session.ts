import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { forkSession } from "@anthropic-ai/claude-agent-sdk";

const exec = promisify(execFile);

/** SDK disk helpers use process-global account state. Isolate them, not process.env. */
export async function forkPersistedSession(sessionId: string, cwd: string, at: string, configDir?: string): Promise<{ sessionId: string }> {
	if (!configDir) return forkSession(sessionId, { dir: cwd, upToMessageId: at, title: "pi" });
	const moduleUrl = import.meta.resolve("@anthropic-ai/claude-agent-sdk");
	const code = `import { forkSession } from ${JSON.stringify(moduleUrl)};
const [sessionId, dir, upToMessageId] = process.argv.slice(1);
console.log(JSON.stringify(await forkSession(sessionId, { dir, upToMessageId, title: "pi" })));`;
	const { stdout } = await exec(process.execPath, ["--input-type=module", "-e", code, sessionId, cwd, at], {
		env: { ...process.env, CLAUDE_CONFIG_DIR: configDir },
		timeout: 20_000,
		maxBuffer: 64 * 1024,
	});
	const result = JSON.parse(stdout);
	if (typeof result.sessionId !== "string") throw new Error("Claude SDK fork returned no session id");
	return result;
}
