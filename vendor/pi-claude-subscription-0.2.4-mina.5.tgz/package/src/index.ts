import { appendFileSync } from "node:fs";
import { join } from "node:path";
import { AnchorRegistry } from "./anchors.ts";
import { type ExtensionAPI, getAgentDir, getDocsPath, getExamplesPath, getReadmePath } from "@earendil-works/pi-coding-agent";
import { resolveConfig } from "./config.ts";
import { anthropicChatModels, claudeModels } from "./models.ts";
import { applyClaudePrompt } from "./prompt.ts";
import { API, ClaudeSdkProvider } from "./provider.ts";

export const PROVIDER = "claude-sdk";

/**
 * pi extension: Claude models through the Claude Agent SDK, authenticated by the local Claude
 * Code login (Pro/Max subscription). pi keeps its own agent loop, tools, prompt and compaction;
 * Claude Code is used only as the authenticated model transport.
 */
export default function (pi: ExtensionAPI) {
	const config = resolveConfig({ cwd: process.cwd(), agentDir: getAgentDir(), env: process.env });
	const debugPath = process.env.PI_CLAUDE_SDK_DEBUG;
	const accounts = [
		{ id: PROVIDER, name: "Claude (subscription via Agent SDK)", configDir: undefined as string | undefined, label: "" },
		...(config.profiles ?? []).map((p) => ({ id: `${PROVIDER}-${p.id}`, name: `Claude ${p.name}`, configDir: p.configDir, label: p.name })),
	].map((account) => ({ ...account, provider: new ClaudeSdkProvider({
		configDir: account.configDir,
		// Profiles never share anchors, even when their Pi transcript bytes match.
		...(account.configDir ? { registry: new AnchorRegistry(join(getAgentDir(), account.id, "anchors.jsonl")) } : {}),
		pathToClaudeCodeExecutable: config.pathToClaudeCodeExecutable,
		...(config.maxSessions ? { maxSessions: config.maxSessions } : {}),
		...(config.idleMinutes ? { idleMs: config.idleMinutes * 60_000 } : {}),
		debug: debugPath ? (msg) => appendFileSync(debugPath, `${new Date().toISOString()} ${account.id} ${msg}\n`) : undefined,
	}) }));

	const register = (models = claudeModels()) => {
		for (const account of accounts) pi.registerProvider(account.id, {
			name: account.name,
			// Claude Code authenticates itself; pi only needs a non-empty key to treat the provider as configured.
			apiKey: "claude-code-login",
			api: API as any,
			baseUrl: "claude-agent-sdk://local",
			models: account.label ? models.map((m) => ({ ...m, name: `${m.name} [${account.label}]` })) : models,
			streamSimple: account.provider.streamSimple,
		});
	};
	register();

	// Pick up Claude models newer than the bundled snapshot from pi's own catalog.
	let refreshed = false;
	pi.on("session_start", (_event, ctx) => {
		if (refreshed) return;
		refreshed = true;
		try {
			const live = anthropicChatModels(ctx.modelRegistry.getAll());
			const known = new Set(claudeModels().map((m) => m.id));
			if (live.some((m) => !/-\d{8}$/.test(m.id) && !known.has(m.id))) register(claudeModels(live));
		} catch {
			// The snapshot stays registered.
		}
	});

	const docs = { readme: getReadmePath(), docs: getDocsPath(), examples: getExamplesPath() };
	pi.on("before_agent_start", (event, ctx) => {
		if (accounts.some((a) => a.id === ctx.model?.provider)) applyClaudePrompt(event, { provider: PROVIDER }, config.promptMode ?? "claude", docs);
	});

	const shutdown = () => { for (const account of accounts) account.provider.shutdown(); };
	pi.on("session_shutdown", () => { shutdown(); process.removeListener("exit", shutdown); });
	process.once("exit", shutdown);
}
