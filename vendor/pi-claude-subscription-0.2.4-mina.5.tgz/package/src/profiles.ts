import { isAbsolute } from "node:path";
import type { AccountProfile } from "./config.ts";

/** Account selection is explicit, absolute, and owner-configured. Fail closed on mistakes. */
export function accountProfiles(value: unknown): AccountProfile[] {
	if (value === undefined) return [];
	if (!Array.isArray(value)) throw new Error("claude-sdk.json: profiles must be an array");
	const ids = new Set<string>();
	return value.map((p) => {
		if (!p || typeof p.id !== "string" || !/^[a-z][a-z0-9-]*$/.test(p.id) ||
			typeof p.name !== "string" || !p.name.trim() ||
			typeof p.configDir !== "string" || !isAbsolute(p.configDir)) {
			throw new Error("claude-sdk.json: each profile needs an id, name, and absolute configDir");
		}
		if (ids.has(p.id)) throw new Error("claude-sdk.json: duplicate profile id");
		ids.add(p.id);
		return { id: p.id, name: p.name.trim(), configDir: p.configDir };
	});
}
